const ethers = require("ethers");
const abi = require("./abi.json")
const pair_abi = require("./pair_abi.json")
const provider = new ethers.providers.JsonRpcProvider('https://eth-goerli.g.alchemy.com/v2/-IAWnLgBa7yqZ3B2ImokR0eyEEhdWKk5')
const token_abi = require("./token_abi.json");
// const provider = ethers.getDefaultProvider()
const uniswapFactoryAddress = "0x";
const uniswapFactory = new ethers.Contract(uniswapFactoryAddress,abi,provider);

const basecoin = "0x";

const Liquiditytrack=async(tokenAddr)=>{
    const pairAddress = await uniswapFactory.getPair(basecoin,tokenAddr);
    if(pairAddress=="0x0000000000000000000000000000000000000000") return;
  
    console.log("start")
    let pairContract = new ethers.Contract(pairAddress,pair_abi,provider)
    let tokenContract = new ethers.Contract(tokenAddr, token_abi,provider);
    let amount =await tokenContract.balanceOf(pairAddress);
    amount > 0 ? console.log("Trading Enabled"): console.log("Trading Disabled");
    pairContract.on("Mint", async (e) => {
        console.log("Liquidity has been added");
        amount =await tokenContract.balanceOf(pairAddress);
        amount > 0 ? console.log("Trading Enabled"): console.log("Trading Disabled");
    })
    pairContract.on("Burn", async (e) => {
        console.log("Liquidity has been removed");
        amount =await tokenContract.balanceOf(pairAddress);
        amount > 0 ? console.log("Trading Enabled"): console.log("Trading Disabled");
    })
        
     
        
          
}
Liquiditytrack();
